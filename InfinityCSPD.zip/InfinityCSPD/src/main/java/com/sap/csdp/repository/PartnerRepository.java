package com.sap.csdp.repository;


import java.util.List;
import com.sap.csdp.entities.Partner;
import org.springframework.data.repository.CrudRepository;


public interface PartnerRepository extends CrudRepository<Partner, String> {
	
	List<Partner> findByPid(String pid);
	List<Partner> findByRole(String role);
	List<Partner> findByEmail(String email);

}
