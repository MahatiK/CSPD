package com.sap.csdp.entities;


import java.util.*;
import javax.persistence.*;
import java.io.Serializable;
import com.sap.csdp.annotations.*;



@Entity
@Table(name = "partner_master")
@Inheritance(strategy = InheritanceType.JOINED)
@NamedQuery(name = "Partner.findAll", query = "SELECT p FROM Partner p")
public class Partner implements Serializable {


	private static final long serialVersionUID = 1L;

	@Id
	@Sap
	@SAPLineItem
	@Column(name = "partner_id")
	@TableGenerator(name = "partner_generator", table = "sequence_table", pkColumnName = "present_index_of", pkColumnValue = "partner", initialValue = 10, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "partner_generator")
	protected String pid;

	@Sap
	@SAPLineItem
	@Column(name = "first_name", unique = false, nullable = true)
	protected String firstName;

	@Sap
	@SAPLineItem
	@Column(name = "last_name", unique = false, nullable = true)
	protected String lastName;

	@Sap
	@SAPLineItem
	@Column(name = "email", unique = true, nullable = false)
	protected String email;
	
	@Sap
	@SAPLineItem
	@Column(name = "phone", unique = false, nullable = true)
	protected String phone;
	
	@Sap
	@SAPLineItem
	@Column(name = "address", unique = false, nullable = true)
	protected String address;

	@Sap
	@SAPLineItem
	@Column(name = "country", unique = false, nullable = true)
	protected String country;
	
	@Sap
	@SAPLineItem
	@Column(name = "gov_id", unique = false, nullable = true)
	protected String govId;
	
	@Sap
	@SAPLineItem
	@Column(name = "role", unique = false, nullable = false)
	protected String role = null;
	
	@Sap
	@SAPLineItem
	@Column(name = "rating", unique = false, nullable = true)
	private int rating;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	private List<Parcel> parcels = new ArrayList<Parcel>();
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	private List<Journey> journey = new ArrayList<Journey>();



	public Partner() {
	}

	public Partner(String firstName, String lastName, String email, String phone, String address, String country, String govId, String role, int rating) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.phone = phone;
		this.address = address;
		this.country = country;
		this.govId = govId;
		this.role = role;
		this.rating = rating;
	}


	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getGovId() {
		return govId;
	}

	public void setGovId(String govId) {
		this.govId = govId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public List<Parcel> getParcels() {
		return parcels;
	}

	public void setParcels(List<Parcel> parcels) {
		this.parcels = parcels;
	}

	public List<Journey> getJourney() {
		return journey;
	}

	public void setJourney(List<Journey> journey) {
		this.journey = journey;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((pid == null) ? 0 : pid.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Partner other = (Partner) obj;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		return true;
	}

}
