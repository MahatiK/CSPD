package com.sap.csdp;


import java.util.List;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;



@SpringBootApplication
@SuppressWarnings("unused")
public class OdataServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OdataServiceApplication.class, args);
	}


	@Bean
	public WebMvcConfigurer corsConfigurer() {
		return new WebMvcConfigurerAdapter() {
			@Override
			public void addCorsMappings(CorsRegistry registry) {
				registry.addMapping("/").allowedOrigins("*");
			}
		};
	}




	/*
	@Bean
	public CommandLineRunner demo(final CarrierRepository repository) {
		return new CommandLineRunner() {
			public void run(String... args) throws Exception {
				if (repository.count() == 0) {

					// Creating a party object of type carrier.
					Party party = new Party();
					repository.save(party);
				}
			}
		};
	}
	*/


}
