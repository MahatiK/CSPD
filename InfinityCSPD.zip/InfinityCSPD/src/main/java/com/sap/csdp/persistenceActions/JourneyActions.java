package com.sap.csdp.persistenceActions;


import java.io.*;
import java.util.*;
import com.sap.csdp.entities.*;
import com.sap.csdp.repository.*;
import com.sap.csdp.utils.SpringContextsUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.olingo.odata2.api.uri.KeyPredicate;
import org.apache.olingo.odata2.api.uri.info.DeleteUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntitySetUriInfo;
import org.apache.olingo.odata2.api.uri.info.PostUriInfo;
import org.apache.olingo.odata2.api.uri.info.PutMergePatchUriInfo;
import org.apache.olingo.odata2.jpa.processor.api.ODataJPAResponseBuilder;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.apache.olingo.odata2.api.exception.ODataException;
import org.apache.olingo.odata2.api.processor.ODataResponse;


@Component
@Scope("prototype")
public class JourneyActions implements PersistenceActions {
	
	protected Boolean delivered, status;
	protected String pid, source, destination, weight, dimensions, sentDate, deliveredDate, latLong, inputLine, request, startDate;
	
	JourneyRepository journeyRepo = (JourneyRepository) SpringContextsUtil.getBean("journeyRepository");
	PartnerRepository partnerRepo = (PartnerRepository) SpringContextsUtil.getBean("partnerRepository");
	

	@Override
	@SuppressWarnings({ "unchecked" })
	public ODataResponse doCreate(PostUriInfo arg0, InputStream arg1, String arg2, String arg3, ODataJPAResponseBuilder responseBuilder) throws ODataException {
		
		pid = ""; inputLine = ""; request = ""; source = ""; destination = ""; dimensions = ""; sentDate = ""; deliveredDate = ""; latLong = ""; weight = ""; startDate = "";
		
		ObjectMapper mapper = new ObjectMapper();
		HashMap<String,String> JSONdata = new HashMap<String,String>();
		
		BufferedReader br = new BufferedReader(new InputStreamReader(arg1));
		try {
			while ((inputLine = br.readLine()) != null) {
				request += inputLine;
			}
			JSONdata = mapper.readValue(request, HashMap.class);
		} catch (IOException e) { }
		
		
		Iterator<KeyPredicate> it = arg0.getKeyPredicates().iterator();
		while (it.hasNext()) {
			KeyPredicate kp = it.next();
			pid = kp.getLiteral();
		}
		
		startDate = JSONdata.get("startDate");
		source = JSONdata.get("source");
		destination = JSONdata.get("destination");
		weight = JSONdata.get("weight");
		dimensions = JSONdata.get("dimensions");
		sentDate = JSONdata.get("sentDate");
		deliveredDate = JSONdata.get("deliveredDate");
		latLong = JSONdata.get("latLong");
		try {
			delivered = Boolean.parseBoolean(JSONdata.get("delivered"));
		} catch(Exception e) { delivered = false; }
		try {
			status = Boolean.parseBoolean(JSONdata.get("status"));
		} catch(Exception e) { status = false; }
		
		
		Partner partner = partnerRepo.findOne(pid);
		List<Journey> journeyList = partner.getJourney();
		
		Journey newJourney = new Journey(source, destination, startDate, weight, dimensions, status, latLong);
		journeyList.add(newJourney);

		partnerRepo.save(partner);
		journeyRepo.save(newJourney);
		
		return responseBuilder.build(arg0, newJourney, arg2);
	}
	
	

	@Override
	public ODataResponse doRead(GetEntitySetUriInfo arg0, String arg1, ODataJPAResponseBuilder responseBuilder)throws ODataException {
		return null;
	}

	@Override
	public ODataResponse doUpdate(PutMergePatchUriInfo arg0, InputStream arg1, String arg2, boolean arg3,String arg4, ODataJPAResponseBuilder responseBuilder)throws ODataException {
		return null;
	}


	@Override
	public ODataResponse doDelete(DeleteUriInfo arg0, String arg1, ODataJPAResponseBuilder responseBuilder)throws ODataException {
		return null;
	}


}











//package com.sap.csdp.persistenceActions;
//
//
//import java.io.*;
//import java.util.*;
//import com.sap.csdp.entities.*;
//import com.sap.csdp.repository.*;
//import com.sap.csdp.utils.SpringContextsUtil;
//import org.springframework.stereotype.Component;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import org.springframework.context.annotation.Scope;
//import org.apache.olingo.odata2.api.uri.info.PostUriInfo;
//import org.apache.olingo.odata2.api.uri.KeyPredicate;
//import org.apache.olingo.odata2.api.uri.info.DeleteUriInfo;
//import org.apache.olingo.odata2.api.processor.ODataResponse;
//import org.apache.olingo.odata2.api.exception.ODataException;
//import org.apache.olingo.odata2.api.uri.info.GetEntitySetUriInfo;
//import org.apache.olingo.odata2.api.uri.info.PutMergePatchUriInfo;
//import org.apache.olingo.odata2.jpa.processor.api.ODataJPAResponseBuilder;
//
//
//
//@Component
//@Scope("prototype")
//public class JourneyActions extends PartyActions {
//
//
//
//	@Override
//	@SuppressWarnings("unchecked")
//	public ODataResponse doCreate(PostUriInfo arg0, InputStream arg1, String arg2, String arg3, ODataJPAResponseBuilder responseBuilder) throws ODataException {
//		
//		String inputLine, request;
//		Boolean status; float weight = 0;
//		String source, destination, startDate, dimensions;
//		inputLine = ""; request = ""; source = ""; destination = ""; dimensions = ""; startDate = ""; dimensions = "";
//		
//		PartyRepository partyRepo = (PartyRepository) SpringContextsUtil.getBean("partyRepository");
//		ShipperRepository shipperRepo = (ShipperRepository) SpringContextsUtil.getBean("shipperRepository");
//		JourneyRepository journeyRepo = (JourneyRepository) SpringContextsUtil.getBean("journeyRepository");
//		
//		// Jackson Object and HashMap to handle JSON.
//		ObjectMapper mapper = new ObjectMapper();
//		HashMap<String,String> JSONdata = new HashMap<String,String>();
//		
//		// Extracting the JSON data passed through HTTP-POST request.
//		BufferedReader br = new BufferedReader(new InputStreamReader(arg1));
//		try {
//			while ((inputLine = br.readLine()) != null) {
//				request += inputLine;
//			}
//			JSONdata = mapper.readValue(request, HashMap.class);
//		} catch (IOException e) { }
//		
//		
//		// Extract the PID of the party.
//		Iterator<KeyPredicate> it = arg0.getKeyPredicates().iterator();
//		while (it.hasNext()) {
//			KeyPredicate kp = it.next();
//			pid = kp.getLiteral();
//		}
//		
//		// Populating variables from JSON.
//		source = JSONdata.get("source");
//		destination = JSONdata.get("destination");
//		startDate = JSONdata.get("startDate");
//		dimensions = JSONdata.get("dimensions");
//		try {
//			status = Boolean.parseBoolean(JSONdata.get("status"));
//		} catch(Exception e) { status = false; }
//		try {
//			weight = Float.parseFloat(JSONdata.get("weight"));
//		} catch(Exception e) { rating = 0; }
//		
//			
//		List<Party> partyList = partyRepo.findByRole("S");
//		Shipper myShipper = new Shipper();
//
//		for( int i = 0; i<partyList.size() ; i++ ) {
//			if(partyList.get(i).getPid().equalsIgnoreCase(pid)){
//				Party temp = partyList.get(i);
//				myShipper.setAddress(temp.getAddress());
//				myShipper.setCountry(temp.getCountry());
//				myShipper.setEmail(temp.getEmail());
//				myShipper.setFirstName(temp.getFirstName());
//				myShipper.setGovId(temp.getGovId());
//				myShipper.setLastName(temp.getFirstName());
//				myShipper.setPhone(temp.getPhone());
//				myShipper.setPid(temp.getPid());
//				myShipper.setRole(temp.getRole());
//			}
//		}
//		
//		List<Journey> journeyList = myShipper.getJourney();
//		Journey newJourney = new Journey(source, destination, startDate, weight, dimensions, status, myShipper);
//		journeyList.add(newJourney);
//		
//		myShipper.setJourney(journeyList);
//		journeyRepo.save(newJourney);
//		shipperRepo.save(myShipper);
//		
//		return responseBuilder.build(arg0, newJourney, arg2);
//	}
//
//
//	@Override
//	public ODataResponse doRead(GetEntitySetUriInfo arg0, String arg1, ODataJPAResponseBuilder responseBuilder)throws ODataException {
//		return null;
//	}
//
//
//
//	@Override
//	public ODataResponse doUpdate(PutMergePatchUriInfo arg0, InputStream arg1, String arg2, boolean arg3,String arg4, ODataJPAResponseBuilder responseBuilder)throws ODataException {
//		return null;
//	}
//
//
//
//	@Override
//	public ODataResponse doDelete(DeleteUriInfo arg0, String arg1, ODataJPAResponseBuilder responseBuilder)throws ODataException {
//		return null;
//	}
//
//
//}
