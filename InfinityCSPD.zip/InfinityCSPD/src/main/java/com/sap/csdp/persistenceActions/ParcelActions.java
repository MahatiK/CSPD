package com.sap.csdp.persistenceActions;


import java.io.*;
import java.util.*;
import com.sap.csdp.entities.*;
import com.sap.csdp.repository.*;
import com.sap.csdp.utils.SpringContextsUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.olingo.odata2.api.uri.KeyPredicate;
import org.apache.olingo.odata2.api.uri.info.DeleteUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntitySetUriInfo;
import org.apache.olingo.odata2.api.uri.info.PostUriInfo;
import org.apache.olingo.odata2.api.uri.info.PutMergePatchUriInfo;
import org.apache.olingo.odata2.jpa.processor.api.ODataJPAResponseBuilder;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.apache.olingo.odata2.api.exception.ODataException;
import org.apache.olingo.odata2.api.processor.ODataResponse;


@Component
@Scope("prototype")
public class ParcelActions implements PersistenceActions {

	protected Boolean delivered;
	protected String pid, source, destination, weight, dimensions, sentDate, deliveredDate, latLong, inputLine, request;
	
	ParcelRepository parcelRepo = (ParcelRepository) SpringContextsUtil.getBean("parcelRepository");
	PartnerRepository partnerRepo = (PartnerRepository) SpringContextsUtil.getBean("partnerRepository");
	
	@Override
	@SuppressWarnings("unchecked")
	public ODataResponse doCreate(PostUriInfo arg0, InputStream arg1, String arg2, String arg3, ODataJPAResponseBuilder responseBuilder) throws ODataException {
		
		pid = ""; inputLine = ""; request = ""; source = ""; destination = ""; dimensions = ""; sentDate = ""; deliveredDate = ""; latLong = "";
		
		ObjectMapper mapper = new ObjectMapper();
		HashMap<String,String> JSONdata = new HashMap<String,String>();
		
		BufferedReader br = new BufferedReader(new InputStreamReader(arg1));
		try {
			while ((inputLine = br.readLine()) != null) {
				request += inputLine;
			}
			JSONdata = mapper.readValue(request, HashMap.class);
		} catch (IOException e) { }
		
		
		Iterator<KeyPredicate> it = arg0.getKeyPredicates().iterator();
		while (it.hasNext()) {
			KeyPredicate kp = it.next();
			pid = kp.getLiteral();
		}
		
		source = JSONdata.get("source");
		destination = JSONdata.get("destination");
		weight = JSONdata.get("weight");
		dimensions = JSONdata.get("dimensions");
		sentDate = JSONdata.get("sentDate");
		deliveredDate = JSONdata.get("deliveredDate");
		latLong = JSONdata.get("latLong");
		try {
			delivered = Boolean.parseBoolean(JSONdata.get("delivered"));
		} catch(Exception e) { delivered = false; }
		
		
		List<Partner> existingPartner = partnerRepo.findByPid(pid);
		Partner partner = existingPartner.get(0);
		List<Parcel> parcelList = partner.getParcels();
		
		Parcel newParcel = new Parcel(source, destination, weight, dimensions, sentDate, deliveredDate, delivered, latLong);
		parcelList.add(newParcel);

		parcelRepo.save(newParcel);
		partnerRepo.save(partner);
		
		return responseBuilder.build(arg0, newParcel, arg2);
	}
	
	

	@Override
	public ODataResponse doRead(GetEntitySetUriInfo arg0, String arg1, ODataJPAResponseBuilder responseBuilder)throws ODataException {
		return null;
	}

	@Override
	public ODataResponse doUpdate(PutMergePatchUriInfo arg0, InputStream arg1, String arg2, boolean arg3,String arg4, ODataJPAResponseBuilder responseBuilder)throws ODataException {
		return null;
	}


	@Override
	public ODataResponse doDelete(DeleteUriInfo arg0, String arg1, ODataJPAResponseBuilder responseBuilder)throws ODataException {
		return null;
	}


}
