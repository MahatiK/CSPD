package com.sap.csdp.entities;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;
import com.sap.csdp.annotations.*;
import com.sap.csdp.entities.Parcel;



@Entity
@Table(name = "journey_master")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class Journey {


	@Id
	@TableGenerator(name = "journey_generator", table = "sequence_table", pkColumnName = "present_index_of", pkColumnValue = "journey", initialValue = 10, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "journey_generator")
	@Column(name = "journey_id")
	private String journeyId;

	@Sap
	@SAPLineItem
	@Column(name = "source", unique = false, nullable = false)
	protected String source;

	@Sap
	@SAPLineItem
	@Column(name = "destination", unique = false, nullable = false)
	protected String destination;

	@Sap
	@SAPLineItem
	@Column(name = "start_date", unique = false, nullable = false)
	protected String startDate;
	
	@Sap
	@SAPLineItem
	@Column(name = "capacity_weight", unique = false, nullable = false)
	protected String weight;
	
	@Sap
	@SAPLineItem
	@Column(name = "capacity_dimensions", unique = false, nullable = false)
	protected String dimensions;
	
	@Sap
	@SAPLineItem
	@Column(name = "journey_status", unique = false, nullable = false)
	protected Boolean status;
	
	@Sap
	@SAPLineItem
	@Column(name = "latLong", unique = false, nullable = false)
	protected String latLong;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "party_id", nullable = true)
	protected Partner partner;
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	private List<Parcel> parcels = new ArrayList<Parcel>();
	
	
	
	public Journey() {
	}


	public Journey(String source, String destination, String startDate, String weight, String dimensions, Boolean status, String latLong) {
		this.source = source;
		this.destination = destination;
		this.startDate = startDate;
		this.weight = weight;
		this.dimensions = dimensions;
		this.status = status;
		this.latLong = latLong;
	}


	public String getJourneyId() {
		return journeyId;
	}


	public void setJourneyId(String journeyId) {
		this.journeyId = journeyId;
	}


	public String getSource() {
		return source;
	}


	public void setSource(String source) {
		this.source = source;
	}


	public String getDestination() {
		return destination;
	}


	public void setDestination(String destination) {
		this.destination = destination;
	}


	public String getStartDate() {
		return startDate;
	}


	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}


	public String getWeight() {
		return weight;
	}


	public void setWeight(String weight) {
		this.weight = weight;
	}


	public String getDimensions() {
		return dimensions;
	}


	public void setDimensions(String dimensions) {
		this.dimensions = dimensions;
	}


	public Boolean getStatus() {
		return status;
	}


	public void setStatus(Boolean status) {
		this.status = status;
	}


	public String getLatLong() {
		return latLong;
	}


	public void setLatLong(String latLong) {
		this.latLong = latLong;
	}


	public Partner getPartner() {
		return partner;
	}


	public void setPartner(Partner partner) {
		this.partner = partner;
	}


	public List<Parcel> getParcels() {
		return parcels;
	}


	public void setParcels(List<Parcel> parcels) {
		this.parcels = parcels;
	}

	
}
