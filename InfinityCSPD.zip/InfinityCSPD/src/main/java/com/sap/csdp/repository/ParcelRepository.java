package com.sap.csdp.repository;


import java.util.List;
import com.sap.csdp.entities.Parcel;
import org.springframework.data.repository.CrudRepository;


public interface ParcelRepository extends CrudRepository<Parcel, String> {

	List<Parcel> findBySourceAndDestination(String source, String destination);
}
