package com.sap.csdp.annotations;


import java.lang.annotation.Target;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;



@Inherited
@Target({FIELD})
@Retention(RUNTIME)
public @interface Sap {
	
	boolean sortable() default true;
	boolean filterable() default true;
	boolean creatable() default true;
	boolean updatable() default true;

}
