package com.sap.csdp.repository;


import java.util.List;
import com.sap.csdp.entities.Journey;
import org.springframework.data.repository.CrudRepository;


public interface JourneyRepository extends CrudRepository<Journey, String> {

	List<Journey> findBySourceAndDestination(String source, String destination);
}
