package com.sap.csdp.persistenceActions;


import java.io.*;
import com.sap.csdp.utils.SpringContextsUtil;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.apache.olingo.odata2.api.uri.info.PostUriInfo;
import org.apache.olingo.odata2.api.uri.info.DeleteUriInfo;
import org.apache.olingo.odata2.api.processor.ODataResponse;
//import org.apache.olingo.odata2.api.commons.HttpStatusCodes;
import org.apache.olingo.odata2.api.exception.ODataException;
import org.apache.olingo.odata2.api.uri.info.GetEntitySetUriInfo;
import org.apache.olingo.odata2.api.uri.info.PutMergePatchUriInfo;
import org.apache.olingo.odata2.jpa.processor.api.ODataJPAResponseBuilder;



@Component
@Scope("prototype")
public class ActionMaster {



	public ODataResponse doCreateEntity(PostUriInfo arg0, InputStream arg1, String arg2, String arg3, ODataJPAResponseBuilder responseBuilder) throws ODataException {
		
		String firstParam = arg0.getStartEntitySet().getName();
		String secondParam = arg0.getTargetEntitySet().getName();
		
		
		if(firstParam.equals("Partners") && secondParam.equals("Partners")) {
			PersistenceActions persistenceActions = (PersistenceActions) SpringContextsUtil.getBean("partnerActions");
			return persistenceActions.doCreate(arg0, arg1, arg2, arg3, responseBuilder);
		}
		
		else if(firstParam.equals("Partners") && secondParam.equals("Parcels")) {
			PersistenceActions persistenceActions = (PersistenceActions) SpringContextsUtil.getBean("parcelActions");
			return persistenceActions.doCreate(arg0, arg1, arg2, arg3, responseBuilder);
		}
		
		else if(firstParam.equals("Partners") && secondParam.equals("Journeys")) {
			PersistenceActions persistenceActions = (PersistenceActions) SpringContextsUtil.getBean("journeyActions");
			return persistenceActions.doCreate(arg0, arg1, arg2, arg3, responseBuilder);
		}
		
		else {
			return null;
		}
		
	}





	public ODataResponse doReadEntitySet(GetEntitySetUriInfo arg0, String arg1, ODataJPAResponseBuilder responseBuilder) throws ODataException {
		return null;
	}





	public ODataResponse doUpdateEntity(PutMergePatchUriInfo arg0, InputStream arg1, String arg2, boolean arg3, String arg4, ODataJPAResponseBuilder responseBuilder) throws ODataException {
		return null;
	}





	public ODataResponse doDeleteEntity(DeleteUriInfo arg0, String arg1, ODataJPAResponseBuilder responseBuilder) throws ODataException {
		return null;
	}



}
