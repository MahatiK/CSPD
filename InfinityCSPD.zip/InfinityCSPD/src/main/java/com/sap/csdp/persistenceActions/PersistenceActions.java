
package com.sap.csdp.persistenceActions;


import java.io.*;
import org.apache.olingo.odata2.api.uri.info.*;
import org.apache.olingo.odata2.api.processor.ODataResponse;
import org.apache.olingo.odata2.api.exception.ODataException;
import org.apache.olingo.odata2.jpa.processor.api.ODataJPAResponseBuilder;



public interface PersistenceActions {
	
	abstract ODataResponse doCreate(PostUriInfo arg0, InputStream arg1, String arg2, String arg3, ODataJPAResponseBuilder responseBuilder) throws ODataException;
	abstract ODataResponse doRead(GetEntitySetUriInfo arg0, String arg1, ODataJPAResponseBuilder responseBuilder) throws ODataException;
	abstract ODataResponse doUpdate(PutMergePatchUriInfo arg0, InputStream arg1, String arg2, boolean arg3, String arg4, ODataJPAResponseBuilder responseBuilder) throws ODataException;
	abstract ODataResponse doDelete(DeleteUriInfo arg0, String arg1, ODataJPAResponseBuilder responseBuilder) throws ODataException;

}
