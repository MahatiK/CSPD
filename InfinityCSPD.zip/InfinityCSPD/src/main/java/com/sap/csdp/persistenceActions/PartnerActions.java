package com.sap.csdp.persistenceActions;


import java.io.*;
import java.util.*;
import com.sap.csdp.entities.*;
import com.sap.csdp.repository.*;
import com.sap.csdp.utils.SpringContextsUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.olingo.odata2.api.uri.KeyPredicate;
import org.apache.olingo.odata2.api.uri.info.DeleteUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntitySetUriInfo;
import org.apache.olingo.odata2.api.uri.info.PostUriInfo;
import org.apache.olingo.odata2.api.uri.info.PutMergePatchUriInfo;
import org.apache.olingo.odata2.jpa.processor.api.ODataJPAResponseBuilder;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.apache.olingo.odata2.api.exception.ODataException;
import org.apache.olingo.odata2.api.processor.ODataResponse;


@Component
@Scope("prototype")
public class PartnerActions implements PersistenceActions {

	protected int rating;
	PartnerRepository partnerRepo = (PartnerRepository) SpringContextsUtil.getBean("partnerRepository");
	protected String pid, firstName, lastName, email, phone, address, country, govId, role, inputLine, request;
	
	@Override
	@SuppressWarnings("unchecked")
	public ODataResponse doCreate(PostUriInfo arg0, InputStream arg1, String arg2, String arg3, ODataJPAResponseBuilder responseBuilder) throws ODataException {

		inputLine = ""; request = ""; pid = ""; firstName = ""; lastName = ""; email = ""; phone = ""; address = ""; country = ""; govId = ""; role = ""; rating = 0;
		
		ObjectMapper mapper = new ObjectMapper();
		HashMap<String,String> JSONdata = new HashMap<String,String>();
		
		// Extracting the JSON data passed through HTTP-POST request.
		BufferedReader br = new BufferedReader(new InputStreamReader(arg1));
		try {
			while ((inputLine = br.readLine()) != null) {
				request += inputLine;
			}
			JSONdata = mapper.readValue(request, HashMap.class);
		} catch (IOException e) { }
		
		
		// Extract the PID of the party.
		Iterator<KeyPredicate> it = arg0.getKeyPredicates().iterator();
		while (it.hasNext()) {
			KeyPredicate kp = it.next();
			pid = kp.getLiteral();
		}
		
		firstName = JSONdata.get("firstName");
		lastName = JSONdata.get("lastName");
		email = JSONdata.get("email");
		phone = JSONdata.get("phone");
		address = JSONdata.get("address");
		country = JSONdata.get("country");
		govId = JSONdata.get("govId");
		role = JSONdata.get("role");
		try {
			rating = Integer.parseInt(JSONdata.get("rating"));
		} catch(Exception e) {
			rating = 0;
		}
	
		List<Partner> existingPartner = partnerRepo.findByEmail(email);
		if (existingPartner.isEmpty()) {
			Partner partner = new Partner(firstName, firstName, email, phone, address, country, govId, role, rating);
			partnerRepo.save(partner);
			return responseBuilder.build(arg0, partner, arg2);
		} else {
			existingPartner.get(0).setRole(role);
			partnerRepo.save(existingPartner.get(0));
			return responseBuilder.build(arg0, existingPartner.get(0), arg2);
		}
	}
	
	@Override
	public ODataResponse doRead(GetEntitySetUriInfo arg0, String arg1, ODataJPAResponseBuilder responseBuilder)throws ODataException {
		return null;
	}


	@Override
	public ODataResponse doUpdate(PutMergePatchUriInfo arg0, InputStream arg1, String arg2, boolean arg3,String arg4, ODataJPAResponseBuilder responseBuilder)throws ODataException {
		return null;
	}


	@Override
	public ODataResponse doDelete(DeleteUriInfo arg0, String arg1, ODataJPAResponseBuilder responseBuilder)throws ODataException {
		return null;
	}

}
