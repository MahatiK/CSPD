package com.sap.csdp.entities;


import javax.persistence.*;
import com.sap.csdp.annotations.*;



@Entity
@Table(name = "parce_master")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class Parcel {


	@Id
	@TableGenerator(name = "parce_generator", table = "sequence_table", pkColumnName = "present_index_of", pkColumnValue = "parce", initialValue = 10, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "parce_generator")
	@Column(name = "parcel_id")
	private String parcelId;

	@Sap
	@SAPLineItem
	@Column(name = "source", unique = false, nullable = false)
	protected String source;

	@Sap
	@SAPLineItem
	@Column(name = "destination", unique = false, nullable = false)
	protected String destination;

	@Sap
	@SAPLineItem
	@Column(name = "weight", unique = false, nullable = false)
	protected String weight;
	
	@Sap
	@SAPLineItem
	@Column(name = "dimentions", unique = false, nullable = false)
	protected String dimensions;
	
	@Sap
	@SAPLineItem
	@Column(name = "shipping_date", unique = false, nullable = false)
	protected String sentDate;
	
	@Sap
	@SAPLineItem
	@Column(name = "delivered_date", unique = false, nullable = false)
	protected String deliveredDate;
	
	@Sap
	@SAPLineItem
	@Column(name = "delivered_status", unique = false, nullable = false)
	protected Boolean delivered;
	
	@Sap
	@SAPLineItem
	@Column(name = "latLong", unique = false, nullable = false)
	protected String latLong;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "party_id", nullable = true)
	protected Partner sender;
	
//	@JoinColumn(name = "party_id", nullable = true)
	@ManyToOne(fetch = FetchType.EAGER)
	protected Partner shipper;


	
	public Parcel() {
	}

	public Parcel(String source, String destination, String weight, String dimensions, String sentDate,String deliveredDate, Boolean delivered, String latLong) {
		this.source = source;
		this.destination = destination;
		this.weight = weight;
		this.dimensions = dimensions;
		this.sentDate = sentDate;
		this.deliveredDate = deliveredDate;
		this.delivered = delivered;
		this.latLong = latLong;
	}

	public String getParcelId() {
		return parcelId;
	}

	public void setParcelId(String parcelId) {
		this.parcelId = parcelId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public String getDimensions() {
		return dimensions;
	}

	public void setDimensions(String dimensions) {
		this.dimensions = dimensions;
	}

	public String getSentDate() {
		return sentDate;
	}

	public void setSentDate(String sentDate) {
		this.sentDate = sentDate;
	}

	public String getDeliveredDate() {
		return deliveredDate;
	}

	public void setDeliveredDate(String deliveredDate) {
		this.deliveredDate = deliveredDate;
	}

	public Boolean getDelivered() {
		return delivered;
	}

	public void setDelivered(Boolean delivered) {
		this.delivered = delivered;
	}

	public String getLatLong() {
		return latLong;
	}

	public void setLatLong(String latLong) {
		this.latLong = latLong;
	}

	public Partner getSender() {
		return sender;
	}

	public void setSender(Partner sender) {
		this.sender = sender;
	}

	public Partner getShipper() {
		return shipper;
	}

	public void setShipper(Partner shipper) {
		this.shipper = shipper;
	}
	
	

	
}
