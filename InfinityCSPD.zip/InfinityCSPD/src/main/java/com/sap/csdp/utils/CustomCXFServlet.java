package com.sap.csdp.utils;


import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.cxf.jaxrs.servlet.CXFNonSpringJaxrsServlet;


public class CustomCXFServlet extends CXFNonSpringJaxrsServlet {

	private static final long serialVersionUID = 1L;


	@Override
	protected void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException {
		response.addHeader("Access-Control-Allow-Origin", "*");
		response.addHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, PUT, DELETE, HEAD");
		response.addHeader("Access-Control-Allow-Headers", "X-PINGOTHER, Origin, X-Requested-With, Content-Type, Accept");
		response.addHeader("Access-Control-Max-Age", "1728000");
		super.handleRequest(request, response);
	}


	@Override
	protected void doOptions(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String method = request.getHeader("Access-Control-Request-Method");

		switch (method) {
			case "GET":
				doGet(request, response);
				break;
				
			case "POST":
				doPost(request, response);
				break;
				
			case "PUT":
				doPut(request, response);
				break;
				
			case "DELETE":
				doDelete(request, response);
				break;
				
			case "HEAD":
				doHead(request, response);
				break;
		}
	}


}
