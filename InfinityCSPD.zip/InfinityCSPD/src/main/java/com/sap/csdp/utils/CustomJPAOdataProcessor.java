package com.sap.csdp.utils;


import java.io.*;
import java.util.*;
import com.sap.csdp.persistenceActions.*;

import org.apache.olingo.odata2.api.batch.BatchHandler;
import org.apache.olingo.odata2.api.uri.info.PostUriInfo;
import org.apache.olingo.odata2.api.uri.info.DeleteUriInfo;
import org.apache.olingo.odata2.api.processor.ODataRequest;
import org.apache.olingo.odata2.api.processor.ODataResponse;
import org.apache.olingo.odata2.api.batch.BatchResponsePart;
import org.apache.olingo.odata2.api.exception.ODataException;
import org.apache.olingo.odata2.jpa.processor.api.ODataJPAContext;

import org.apache.olingo.odata2.api.uri.info.GetEntityUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntitySetUriInfo;
import org.apache.olingo.odata2.api.uri.info.PutMergePatchUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntityLinkUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntityCountUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntitySetCountUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntitySetLinksUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetFunctionImportUriInfo;
import org.apache.olingo.odata2.jpa.processor.core.ODataJPAProcessorDefault;



public class CustomJPAOdataProcessor extends ODataJPAProcessorDefault {


	public CustomJPAOdataProcessor(ODataJPAContext oDataJPAContext) {
		super(oDataJPAContext);
	}


	@Override
	public ODataResponse createEntity(PostUriInfo arg0, InputStream arg1, String arg2, String arg3) throws ODataException {
		ActionMaster actionMaster = (ActionMaster) SpringContextsUtil.getBean("actionMaster");
		ODataResponse response = actionMaster.doCreateEntity(arg0, arg1, arg2, arg3, this.responseBuilder);
		return (response != null) ? (response) : (super.createEntity(arg0, arg1, arg2, arg3));
	}


	@Override
	public ODataResponse countEntitySet(GetEntitySetCountUriInfo arg0, String arg1) throws ODataException {
		return super.countEntitySet(arg0, arg1);
	}


	@Override
	public ODataResponse createEntityLink(PostUriInfo uriParserResultView, InputStream content, String requestContentType, String contentType) throws ODataException {
		return super.createEntityLink(uriParserResultView, content, requestContentType, contentType);
	}


	@Override
	public ODataResponse deleteEntity(DeleteUriInfo arg0, String arg1) throws ODataException {
		return super.deleteEntity(arg0, arg1);
	}


	@Override
	public ODataResponse deleteEntityLink(DeleteUriInfo uriParserResultView, String contentType) throws ODataException {
		return super.deleteEntityLink(uriParserResultView, contentType);
	}


	@Override
	public ODataResponse executeBatch(BatchHandler arg0, String arg1, InputStream arg2) throws ODataException {
		return super.executeBatch(arg0, arg1, arg2);
	}


	@Override
	public BatchResponsePart executeChangeSet(BatchHandler arg0, List<ODataRequest> arg1) throws ODataException {
		return super.executeChangeSet(arg0, arg1);
	}


	@Override
	public ODataResponse executeFunctionImport(GetFunctionImportUriInfo arg0, String arg1) throws ODataException {
		return super.executeFunctionImport(arg0, arg1);
	}


	@Override
	public ODataResponse executeFunctionImportValue(GetFunctionImportUriInfo arg0, String arg1) throws ODataException {
		return super.executeFunctionImportValue(arg0, arg1);
	}


	@Override
	public ODataResponse existsEntity(GetEntityCountUriInfo arg0, String arg1) throws ODataException {
		return super.existsEntity(arg0, arg1);
	}


	@Override
	public ODataResponse readEntity(GetEntityUriInfo arg0, String arg1) throws ODataException {
		return super.readEntity(arg0, arg1);
	}


	@Override
	public ODataResponse readEntityLink(GetEntityLinkUriInfo arg0, String arg1) throws ODataException {
		return super.readEntityLink(arg0, arg1);
	}


	@Override
	public ODataResponse readEntityLinks(GetEntitySetLinksUriInfo arg0, String arg1) throws ODataException {
		return super.readEntityLinks(arg0, arg1);
	}


	@Override
	public ODataResponse readEntitySet(GetEntitySetUriInfo arg0, String arg1) throws ODataException {
		ActionMaster actionMaster = (ActionMaster) SpringContextsUtil.getBean("actionMaster");
		ODataResponse response = actionMaster.doReadEntitySet(arg0, arg1, this.responseBuilder);
		return (response != null) ? (response) : (super.readEntitySet(arg0, arg1));
	}


	@Override
	public ODataResponse updateEntity(PutMergePatchUriInfo arg0, InputStream arg1, String arg2, boolean arg3, String arg4) throws ODataException {
		ActionMaster actionMaster = (ActionMaster) SpringContextsUtil.getBean("actionMaster");
		ODataResponse response = actionMaster.doUpdateEntity(arg0, arg1, arg2, arg3, arg4, this.responseBuilder);
		return (response != null) ? (response) : (super.updateEntity(arg0, arg1, arg2, arg3, arg4));
	}


	@Override
	public ODataResponse updateEntityLink(PutMergePatchUriInfo uriParserResultView, InputStream content, String requestContentType, String contentType) throws ODataException {
		return super.updateEntityLink(uriParserResultView, content, requestContentType, contentType);
	}


}
